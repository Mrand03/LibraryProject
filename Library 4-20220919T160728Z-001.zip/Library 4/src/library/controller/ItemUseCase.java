/* 
 * ItemUseCase.java
 */
package library.controller;

import library.gui.GUI;
import library.model.LibraryDatabase;
import library.model.Copy;
import library.model.Book; 
import library.model.DVD; 
import library.model.Item;

/** This is the controller for the use case that manages the items within
 *  the library database 
 *
 *  @author Sofi Stonehouse, Jason Asonye, Daniel Lovelace, and Mya Randolph
 */

/*
 * ItemUseCase adds a copy to list and allows information to be put in about the item
 */
public class ItemUseCase {
    
    // Add a copy of each item to the database
    public static void addCopy(Item item){
        Copy copy = item.makeCopy();
        GUI.getInstance().showMessage("Copy " + copy.getCopyNumber() + 
               " has been added to the database.");
    }
    
    // Add a book to the database
    public static void addBook(String callNumber, String title, String author){
        Book book = new Book(callNumber, title, author);
        LibraryDatabase.getInstance().add(book);
    }
    
    // Add a DVD to the database 
    public static void addDVD(String callNumber, String title, String leadActor, String rating){
        DVD dvd = new DVD(callNumber, title, leadActor, rating);
        LibraryDatabase.getInstance().add(dvd);
    }
    
    // Produce an item report 
    public static void produceReport()
    {
        LibraryDatabase libraryDatabase = LibraryDatabase.getInstance();
        libraryDatabase.produceItemsReport();
    }
}
